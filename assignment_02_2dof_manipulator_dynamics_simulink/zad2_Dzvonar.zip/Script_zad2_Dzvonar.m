clear all; clc; close all;
m1 = 3;
m2 = 3; %kg

l1 = 0.25;
l2 = 0.25; %m

B1 = 2; 
B2 = 2; %kg*m^-1

g = 9.81; %m*s^-2

q1ref = 180;
q2ref = 180;
